from django.apps import AppConfig

class CitizenRepoConfig(AppConfig):
    name = "ngao_core.apps.citizen_repo"
    verbose_name = "Citizen Repository (IPRS Mock)"
