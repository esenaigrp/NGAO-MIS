from django.apps import AppConfig


class GeographyConfig(AppConfig):
    name = "geography"
