from django.apps import AppConfig

class IDRegistrationConfig(AppConfig):
    name = 'id_registration'
    verbose_name = "National ID Registration"
