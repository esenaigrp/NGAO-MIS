from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = "ngao_core.apps.accounts"
    label = "accounts"